/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */

function containsItem(options = HTMLCollection, value = String) {
    for (let i = 0, size = options.length; i < size; i++) {
        if (options[i].value === value) {
            return i;
        }
    }

    return -1;
}

function onKeyPressUp(data) {
    if (data.status === "success") {
        const source = data.source;
        const value = source.value;
        const menu = document.getElementById("form:pal_menu");
        const index = containsItem(menu.options, value);

        if (index !== -1) {
            menu.selectedIndex = index;
            menu.disabled = false;
        } else {
            menu.selectedIndex = 0;
            menu.disabled = !menu.disabled;
        }
    }
}

function onBlurAccountInput(data, balance, amount) {
    if (data.status === "success") {
        const source = data.source;
        console.log(source);
        

        const target = document.getElementById("amount_gained");
        if (!amount)
            target.value = balance;
            console.log(target.value);
    }
}

