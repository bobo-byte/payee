package com.webapps2022.entity;

import com.webapps2022.entity.constraints.Email;
import com.webapps2022.entity.listeners.PayPalListener;
import com.webapps2022.utility.Rate;
import com.webapps2022.utility.TransactionStatus;
import com.webapps2022.utility.TransactionType;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 * ORM class for user table.
 *
 * @author Joseph Steven Semgalawe
 */
@Entity
@EntityListeners({PayPalListener.class})
@NamedQueries({
    @NamedQuery(name = PayPal.GET_TRANSACTIONS,
            query = PayPal.GET_TRANSACTIONS_QUERY),
    @NamedQuery(name = PayPal.COUNT_TRANSACTIONS,
            query = PayPal.COUNT_TRANSACTIONS_QUERY),
    @NamedQuery(name = PayPal.GET_TRANSACTION,
            query = PayPal.GET_TRANSACTION_QUERY),
    @NamedQuery(name = PayPal.GET_USER,
            query = PayPal.GET_USER_QUERY), // might no be needed with em.find();
    @NamedQuery(name = PayPal.GET_PALS,
            query = PayPal.GET_PALS_QUERY),
    @NamedQuery(name = PayPal.COUNT_PALS,
            query = PayPal.COUNT_PALS_QUERY),
    @NamedQuery(name = PayPal.GET_PAL,
            query = PayPal.GET_PAL_QUERY)
})
public class PayPal implements Serializable {

    public static final String GET_TRANSACTIONS = "GET_TRANSACTIONS";
    public static final String GET_TRANSACTIONS_QUERY = "SELECT t FROM PayPal p"
            + " LEFT JOIN p.transactions t WHERE p.username = :username";
    public static final String COUNT_TRANSACTIONS = "COUNT_TRANSACTIONS";
    public static final String COUNT_TRANSACTIONS_QUERY = "SELECT COUNT(t) FROM PayPal p"
            + " LEFT JOIN p.transactions t WHERE p.username = :username";

    public static final String GET_TRANSACTION = "GET_TRANSACTION";
    public static final String GET_TRANSACTION_QUERY = "SELECT DISTINCT t "
            + "FROM PayPal p"
            + " LEFT JOIN p.transactions t WHERE t.id = :transactionID";

    public static final String GET_USER = "GET_USER";
    public static final String GET_USER_QUERY = "SELECT DISTINCT p "
            + "FROM PayPal p WHERE p.username = :username";

    public static final String GET_PALS = "GET_PALS";
    public static final String GET_PALS_QUERY = "SELECT p "
            + "FROM PayPal u"
            + " LEFT JOIN u.pals p WHERE u.username = :username";

    public static final String COUNT_PALS = "COUNT_PALS";
    public static final String COUNT_PALS_QUERY = "SELECT COUNT(p) "
            + "FROM PayPal u"
            + " LEFT JOIN u.pals p WHERE u.username = :username";

    public static final String GET_PAL = "GET_PAL";
    public static final String GET_PAL_QUERY = "SELECT p FROM PayPal u"
            + " LEFT JOIN u.pals p WHERE p.username = :username";

    @Id
    @NotNull
    @Column(nullable = false)
    private String username;

    @Email
    @Column(nullable = false)
    private String email;

    @Column(nullable = true)
    private String password;

    @OneToMany(fetch = FetchType.EAGER,
            mappedBy = "user",
            cascade = {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH})
    @JoinColumn(name = "transaction_fk")
    private List<PayPalTransaction> transactions;
    // update transactions only when we remove from database and manged state.
    // when we add to managed state [to sychornise any changes]
    // when we update the object by refreshing to synchonise changes.

    @Column(nullable = false)
    private float amount = 1000;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private Rate rate = Rate.GBP;

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createAt = new Date();

    @ManyToMany(cascade = {
        CascadeType.MERGE,
        CascadeType.PERSIST,
        CascadeType.REFRESH,
        CascadeType.REMOVE,},
            fetch = FetchType.EAGER
    )
    @JoinTable(name = "paypal_pal",
            joinColumns = @JoinColumn(name = "paypal_username"),
            inverseJoinColumns = @JoinColumn(name = "pal_username"))
    private Set<PayPal> pals;

    @ManyToMany(cascade = {
        CascadeType.MERGE,
        CascadeType.PERSIST,
        CascadeType.REFRESH,
        CascadeType.REMOVE
    },
            fetch = FetchType.EAGER,
            mappedBy = "pals")
    private Set<PayPal> palsOf;

    /**
     * Getter for email
     *
     * @return user email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Setter for email
     *
     * @param email email to overwrite
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Getter method for username.
     *
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Setter method for username.
     *
     * @param username username to overwrite
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Getter for the users password
     *
     * @return digested password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter for the users password.
     *
     * @param password user password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Getter for users pay pals
     *
     * @return list of pay pals
     */
    public Set<PayPal> getPals() {
        return pals;
    }

    /**
     * Setter for users pay pals
     *
     * @param pals list of pals
     */
    public void setPals(Set<PayPal> pals) {
        this.pals = pals;
    }

    /**
     * Getter for pals of the user
     *
     * @return list of pals
     */
    public Set<PayPal> getPalsOf() {
        return palsOf;
    }

    /**
     * Setter for pas of the user
     *
     * @param palsOf list of pals
     */
    public void setPalsOf(Set<PayPal> palsOf) {
        this.palsOf = palsOf;
    }

    /**
     * Adds a child to parent
     *
     * @param pal pal to add
     */
    public void addPal(PayPal pal) {
        this.getPals().add(pal);
        pal.getPalsOf().add(this);
    }

    /**
     * Adds the parent to the pals list
     *
     * @param pal parent pal
     */
    public void addPalOf(PayPal pal) {
        this.getPalsOf().add(pal);
        pal.getPals().add(this);
    }

    public List<PayPalTransaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<PayPalTransaction> transactions) {
        this.transactions = transactions;
    }

    public void addTransferTransaction(float amount, String reference,
            Rate currency, String recepient) {
        PayPalTransaction transaction = new PayPalTransaction();
        transaction.setAmount(amount);
        transaction.setRecepient(recepient);
        transaction.setReferenceDescription(reference);
        transaction.setCurrency(currency);
        transaction.setStatus(TransactionStatus.ACCEPTED);
        transaction.setType(TransactionType.TRANSFER);
        transaction.setUser(this);

        getTransactions()
                .add(transaction);
    }

    public void addRequestTransaction(float amount, String reference,
            Rate currency, String recepient) {
        PayPalTransaction transaction = new PayPalTransaction();
        transaction.setAmount(amount);
        transaction.setRecepient(recepient);
        transaction.setReferenceDescription(reference);
        transaction.setCurrency(currency);
        transaction.setStatus(TransactionStatus.PENDING);
        transaction.setType(TransactionType.REQUEST);
        transaction.setUser(this);

        getTransactions()
                .add(transaction);

    }

//    public PayPalMeta getMeta() {
//        return meta;
//    }
//
//    public void setMeta(PayPalMeta meta) {
//        this.meta = meta;
//    }
    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Rate getRate() {
        return rate;
    }

    public void setRate(Rate rate) {
        this.rate = rate;
    }

    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + Objects.hashCode(this.username);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PayPal other = (PayPal) obj;
        return Objects.equals(this.username, other.username);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("User{");
        sb.append("username=").append(username);
        sb.append('}');
        return sb.toString();
    }

}
