/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;

import com.webapps2022.utility.Rate;
import java.util.Date;
import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Class for Pay pal meta data
 *
 * @author Joseph Steven Semgalawe
 */
@Embeddable
@Access(AccessType.PROPERTY)
public class PayPalMeta {
//
//    @Column(nullable = false)

    private float amount = 1000;

//    @Column(nullable = false)
//    @Enumerated(EnumType.STRING)
    private Rate rate = Rate.GBP;

//    @Column(nullable = false)
//    @Temporal(TemporalType.TIMESTAMP)
    private Date createAt = new Date();

    @Column(nullable = false)
    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    public Rate getRate() {
        return rate;
    }

    public void setRate(Rate rate) {
        this.rate = rate;
    }

    @Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    public Date getCreateAt() {
        return createAt;
    }

    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

}
