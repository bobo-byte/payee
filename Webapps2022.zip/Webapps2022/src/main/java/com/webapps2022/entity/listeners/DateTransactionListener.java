/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity.listeners;

import com.webapps2022.entity.PayPalTransaction;
import com.webapps2022.utility.TransactionStatus;
import java.util.Date;
import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;

/**
 *
 * @author Joseph Steven Semgalawe
 */
public class DateTransactionListener {

    /**
     * Callback method for updating the requested and completedAt date times of
     * a transaction
     *
     * @param action transaction from callback event
     */
    @PostPersist
    @PostUpdate
    private void updateDate(PayPalTransaction action) {
        if (action.getStatus() == TransactionStatus.PENDING) {
            action.setRequestedAt(new Date());
        }

        if (action.getStatus() == TransactionStatus.ACCEPTED || action.getStatus() == TransactionStatus.REJECTED) {
            action.setCompletedAt(new Date());
        }

        System.out.println(action.getUser().getUsername());
        // check which user updated a transaction.
    }

}
