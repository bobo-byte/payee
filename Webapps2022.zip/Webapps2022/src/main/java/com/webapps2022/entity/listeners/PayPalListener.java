/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity.listeners;

/**
 *
 * @author josep
 */
public class PayPalListener {
    
    // TODO: Add event callbacks for PayPal entity
}
