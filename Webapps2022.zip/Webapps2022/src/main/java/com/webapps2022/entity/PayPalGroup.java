/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Joseph Steven Semgalawe
 */
@Entity
@NamedQueries({
    @NamedQuery(name = PayPalGroup.GET_ROLE, query = PayPalGroup.GET_ROLE_QUERY),})
public class PayPalGroup implements Serializable {

    public static final String GET_ROLE = "GET_ROLE";
    public static final String GET_ROLE_QUERY = " SELECT g.role FROM PayPalGroup g "
            + "WHERE g.username = :username";

    @Id
    private String username;

    @NotNull
    @Column(name = "GROUP_ROLE")
    private String role;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 43 * hash + Objects.hashCode(this.username);
        hash = 43 * hash + Objects.hashCode(this.role);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PayPalGroup other = (PayPalGroup) obj;
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        return Objects.equals(this.role, other.role);
    }

    @Override
    public String toString() {
        return "PayPalGroup{" + "username=" + username + ", role=" + role + '}';
    }

}
