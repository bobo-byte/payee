/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.entity;

import com.webapps2022.entity.listeners.DateTransactionListener;
import com.webapps2022.utility.Rate;
import com.webapps2022.utility.TransactionStatus;
import com.webapps2022.utility.TransactionType;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Transient;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author Joseph Steven Semgalawe
 */
@EntityListeners({DateTransactionListener.class})
@NamedQueries({
    @NamedQuery(name = PayPalTransaction.GET_STATUS_AS_USER,
            query = PayPalTransaction.GET_STATUS_AS_USER_QUERY),
    @NamedQuery(name = PayPalTransaction.GET_STATUS_AS_RECEPIENT,
            query = PayPalTransaction.GET_STATUS_AS_RECEPIENT_QUERY),
    @NamedQuery(name = PayPalTransaction.COUNT_STATUS_AS_USER,
            query = PayPalTransaction.COUNT_STATUS_AS_USER_QUERY),
    @NamedQuery(name = PayPalTransaction.COUNT_STATUS_AS_RECEPIENT,
            query = PayPalTransaction.COUNT_STATUS_AS_RECEPIENT_QUERY)
})
@Entity
public class PayPalTransaction implements Serializable {

    public static final String GET_STATUS_AS_USER = "GET_STATUS_BY_USER";
    public static final String GET_STATUS_AS_USER_QUERY = "SELECT t "
            + "FROM PayPalTransaction t "
            + "WHERE t.status = :status "
            + "AND t.user.username = :username";

    public static final String GET_STATUS_AS_RECEPIENT
            = "GET_STATUS_AS_RECEPIEN";
    public static final String GET_STATUS_AS_RECEPIENT_QUERY = "SELECT t "
            + "FROM PayPalTransaction t "
            + "WHERE t.status = :status "
            + "AND t.recepient = :username";

    public static final String COUNT_STATUS_AS_USER = "COUNT_STATUS_BY_USER";
    public static final String COUNT_STATUS_AS_USER_QUERY = "SELECT COUNT(t) "
            + "FROM PayPalTransaction t "
            + "WHERE t.status = :status "
            + "AND t.user.username = :username";

    public static final String COUNT_STATUS_AS_RECEPIENT
            = "COUNT_STATUS_BY_RECEIVED";
    public static final String COUNT_STATUS_AS_RECEPIENT_QUERY = "SELECT COUNT(t) "
            + "FROM PayPalTransaction t "
            + "WHERE t.status = :status "
            + "AND t.recepient = :username";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Enumerated(EnumType.STRING)
    TransactionType type;

    @Enumerated(EnumType.STRING)
    TransactionStatus status = TransactionStatus.PENDING;

    @DecimalMin("0.1")
    @NotNull
    @Column(nullable = false)
    private float amount;

    @Enumerated(EnumType.STRING)
    Rate currency = Rate.GBP;

    @Transient
    //@Temporal(TemporalType.TIMESTAMP)
    private Date requestedAt;

    @Transient
    //@Temporal(TemporalType.TIMESTAMP)
    private Date completedAt;

    @NotNull
    @Size(min = 3, max = 18)
    @Column(nullable = false, name = "reference", length = 18)
    private String referenceDescription;

    @Column(name = "recepient_username")
    String recepient;

    @ManyToOne
    @JoinColumn(name = "user_fk", nullable = false)
    PayPal user;

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public TransactionStatus getStatus() {
        return status;
    }

    public void setStatus(TransactionStatus status) {
        this.status = status;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Date getRequestedAt() {
        return requestedAt;
    }

    public void setRequestedAt(Date requestedAt) {
        this.requestedAt = requestedAt;
    }

    public Date getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Date completedAt) {
        this.completedAt = completedAt;
    }

    public PayPal getUser() {
        return user;
    }

    public void setUser(PayPal user) {
        this.user = user;
    }

    public Rate getCurrency() {
        return currency;
    }

    public void setCurrency(Rate currency) {
        this.currency = currency;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReferenceDescription() {
        return referenceDescription;
    }

    public void setReferenceDescription(String referenceDescription) {
        this.referenceDescription = referenceDescription;
    }

    public String getRecepient() {
        return recepient;
    }

    public void setRecepient(String recepient) {
        this.recepient = recepient;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PayPalTransaction)) {
            return false;
        }
        PayPalTransaction other = (PayPalTransaction) object;
        if (this.id == null && (other.id != null || (this.id != null && !this.id.equals(other.id)))) {
        } else {
            return false;
        }

        return true;
    }

    @Override
    public String toString() {
        return "Transaction{id=" + id + "}";
    }

}
