/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.PayPalGroup;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author josep
 */
@Stateless
public class PayPalGroupFacade extends AbstractFacade<PayPalGroup> {

    @PersistenceContext(unitName = "WebappsDBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PayPalGroupFacade() {
        super(PayPalGroup.class);
    }

    public String getUserRole(String username) {
        TypedQuery<String> typedQuery = getEntityManager()
                .createNamedQuery(PayPalGroup.GET_ROLE, String.class);

        typedQuery.setParameter("username", username);

        return typedQuery.getSingleResult();
    }

}
