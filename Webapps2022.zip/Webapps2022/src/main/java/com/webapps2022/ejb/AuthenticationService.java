/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.PayPal;
import com.webapps2022.entity.PayPalGroup;
import com.webapps2022.jsf.util.JsfUtil;
import com.webapps2022.utility.RoleType;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateful;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author Joseph Steven Semgalawe
 */
@Stateful
public class AuthenticationService implements Serializable {

    @EJB
    PayPalFacade dbService;

    @EJB
    PayPalGroupFacade groupService;

    PayPal currentUser;

    @Inject
    PayPalGroup payPalGroup;

    private boolean exists(PayPal pal) {
        return dbService.find(pal.getUsername()) != null;
    }

    public boolean exists(String username) {
        return dbService.find(username) != null;
    }

    public PayPal getCurrentUser() {
        if (currentUser == null) {

            String name = FacesContext.getCurrentInstance().getExternalContext()
                    .getUserPrincipal().getName();

            return dbService.find(name);
        }

        return currentUser;
    }

    public void setCurrentUser(PayPal currentUser) {
        this.currentUser = currentUser;
    }

    public PayPalGroup getPayPalGroup() {
        return payPalGroup;
    }

    public void setPayPalGroup(PayPalGroup payPalGroup) {
        this.payPalGroup = payPalGroup;
    }

    public void register(PayPal pal, RoleType type) throws Exception {
        try {

            if (exists(pal)) {
                System.out.println("User exists in database");
                throw new Exception("User Already exists");
            }
            System.out.println(pal.getUsername());
            System.out.println(pal.getEmail());
            System.out.println(pal.getPassword());

            String hashPassword = hash(pal.getPassword());

            System.out.println("SHA-256: " + hashPassword);
            System.out.println("Role: users");
            System.out.println("Added test success...");

            pal.setPassword(hashPassword);

            payPalGroup.setRole(type.getName());
            payPalGroup.setUsername(pal.getUsername());

            dbService.create(pal);
            groupService.create(payPalGroup);

            setCurrentUser(pal);
            setPayPalGroup(payPalGroup);

//            login(pal.getUsername(), password);
        } catch (Exception e1) {
            JsfUtil.addErrorMessage(e1, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            throw e1;
        }

    }

    public String hash(String password) {
        if (password == null || password.equals("")) {
            return "";
        } else {
            StringBuilder buffer = new StringBuilder();
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(password.getBytes("UTF-8"));
                byte[] digest = md.digest();

                for (int i = 0; i < digest.length; i++) {
                    buffer.append(Integer
                            .toString((digest[i] & 0xff) + 0x100, 16)
                            .substring(1));
                }
            } catch (UnsupportedEncodingException | NoSuchAlgorithmException e1) {
                Logger.getLogger(AuthenticationService.class.getName()).log(Level.SEVERE, null, e1);
            }

            return buffer.toString();
        }
    }

    public void login(String username, String password) throws Exception {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        try {
            //this method will disassociate the principal from the session (effectively logging him/her out)
            request.login(username, password);
            context.addMessage(null, new FacesMessage("User is logged in"));
        } catch (ServletException e) {
            context.addMessage(null, new FacesMessage("Login failed. Try signin up or contact help team!"));
            throw e;
        }
    }

    public void logout() throws Exception {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest();
        try {
            //this method will disassociate the principal from the session (effectively logging him/her out)
            request.logout();
            context.addMessage(null, new FacesMessage("User is logged out"));
        } catch (ServletException e) {
            context.addMessage(null, new FacesMessage("Logout failed."));
            throw e;
        }

    }

}
