/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.PayPal;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author josep
 */
@Local
public interface PayPalFacadeLocal {

    void create(PayPal payPal);

    void edit(PayPal payPal);

    void remove(PayPal payPal);

    PayPal find(Object id);

    List<PayPal> findAll();

    List<PayPal> findRange(int[] range);

    int count();
    
}
