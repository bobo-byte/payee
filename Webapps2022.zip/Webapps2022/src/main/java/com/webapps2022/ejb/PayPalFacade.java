/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.ejb;

import com.webapps2022.entity.PayPal;
import com.webapps2022.entity.PayPalTransaction;
import com.webapps2022.utility.TransactionStatus;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author josep
 */
@Stateless
public class PayPalFacade extends AbstractFacade<PayPal> {

    @PersistenceContext(unitName = "WebappsDBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EntityManager getManager() {
        return em;
    }

    public PayPalFacade() {
        super(PayPal.class);
    }

    public List<PayPal> getUserPalsQuery(String currentUser, int[] range) {
        try {

            if (currentUser == null) {
                currentUser = "bobo9"; // testing
            }

            TypedQuery<PayPal> queryResult = getEntityManager()
                    .createNamedQuery(PayPal.GET_PALS, PayPal.class);
            queryResult.setParameter("username", currentUser);

            queryResult.setMaxResults(range[1] - range[0] + 1);
            queryResult.setFirstResult(range[0]);

            StringBuilder builder = new StringBuilder();

            builder.append("[")
                    .append("PALS")
                    .append("]");

            builder.append(" size: ")
                    .append(queryResult.getResultList().size());

            Logger.getLogger(this.getClass().getName()).log(Level.INFO,
                    builder.toString()
            );

            if (queryResult.getResultList().size() == 1
                    && queryResult.getResultList().get(0) == null) {
                return new ArrayList<>();
            }

            return queryResult.getResultList();

        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE,
                    "UserPalsQuery", e);
        }

        return new ArrayList<>();
    }

    public Stream<PayPal> getUserPalsQuery(String currentUser) {
        try {

            if (currentUser == null) {
                currentUser = "bobo9"; // testing
            }

            TypedQuery<PayPal> queryResult = getEntityManager()
                    .createNamedQuery(PayPal.GET_PALS, PayPal.class);
            queryResult.setParameter("username", currentUser);

            StringBuilder builder = new StringBuilder();

            builder.append("[")
                    .append("PALS")
                    .append("]");

            builder.append(" size: ")
                    .append(queryResult.getResultList().size());

            Logger.getLogger(this.getClass().getName()).log(Level.INFO,
                    builder.toString()
            );

            return queryResult.getResultStream();

        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE,
                    "UserPalsQuery2", e);
        }

        return null;
    }

    public int getUserPalsCount(String currentUser) {
        if (currentUser == null) {
            currentUser = "bobo9"; // testing
        }
        TypedQuery<Long> queryResult = getEntityManager()
                .createNamedQuery(PayPal.COUNT_PALS, Long.class);
        queryResult.setParameter("username", currentUser);

        return queryResult.getSingleResult().intValue();
    }

    public int getTransactionsCount(String username) {
        TypedQuery<Long> queryResult = getEntityManager()
                .createNamedQuery(PayPal.COUNT_TRANSACTIONS, Long.class);
        queryResult.setParameter("username", username);

        return queryResult.getSingleResult().intValue();
    }

    public List<PayPalTransaction> getTransactions(String username, int[] range) {

        try {
            TypedQuery<PayPalTransaction> queryResult = getEntityManager()
                    .createNamedQuery(PayPal.GET_TRANSACTIONS, PayPalTransaction.class);

            queryResult.setMaxResults(range[1] - range[0] + 1);
            queryResult.setFirstResult(range[0]);

            queryResult.setParameter("username", username);

            if (queryResult.getSingleResult() != null) {
                return queryResult.getResultList();
            }

        } catch (NoResultException ex) {
            return new ArrayList<>();
        }

        return new ArrayList<>();
    }

    public List<PayPalTransaction> getTransactionsByStatusQuery(String currentUser,
            TransactionStatus status, int[] range) {
        try {

            String paramName = "status";
            TransactionStatus payload = status;

            if (currentUser == null) {
                currentUser = "bobo5"; // testing
            }

            TypedQuery<PayPalTransaction> queryResult = getEntityManager()
                    .createNamedQuery(PayPalTransaction.GET_STATUS_AS_USER, PayPalTransaction.class);

            queryResult.setMaxResults(range[1] - range[0] + 1);
            queryResult.setFirstResult(range[0]);

            queryResult.setParameter(paramName, payload);
            queryResult.setParameter("username", currentUser);

            StringBuilder builder = new StringBuilder();

            builder.append("[")
                    .append(payload.name())
                    .append("]");

            builder.append(" size: ")
                    .append(queryResult.getResultList().size());

            Logger.getLogger(this.getClass().getName()).log(Level.INFO,
                    builder.toString()
            );

            return queryResult.getResultList();

        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE,
                    "TransactionByStatusQuery",
                    e);
            return new ArrayList<>();
        }
    }

    public int getTransactionsByStatusCount(String currentUser, TransactionStatus status) {
        String paramName = "status";
        TransactionStatus payload = status;

        if (currentUser == null) {
            currentUser = "bobo5"; // testing
        }

        TypedQuery<Long> queryResult = getEntityManager()
                .createNamedQuery(PayPalTransaction.COUNT_STATUS_AS_USER, Long.class);
        queryResult.setParameter(paramName, payload);
        queryResult.setParameter("username", currentUser);

        System.out.println(queryResult.getSingleResult().intValue());

        return queryResult.getSingleResult().intValue();

    }

    public int getUserReceivedTransactionsByStatusCount(String currentUser,
            TransactionStatus status) {
        String paramName = "status";
        TransactionStatus payload = status;

        if (currentUser == null) {
            currentUser = "bobo5"; // testing
        }

        TypedQuery<Long> queryResult = getEntityManager()
                .createNamedQuery(PayPalTransaction.COUNT_STATUS_AS_RECEPIENT,
                        Long.class);
        queryResult.setParameter(paramName, payload);
        queryResult.setParameter("username", currentUser);

        return queryResult.getSingleResult().intValue();
    }

    public List<PayPalTransaction> getUserReceivedTransactionByStatus(String currentUser,
            TransactionStatus status, int[] range) {
        try {

            String paramName = "status";
            TransactionStatus payload = status;

            if (currentUser == null) {
                currentUser = "bobo5"; // testing
            }

            TypedQuery<PayPalTransaction> queryResult = getEntityManager()
                    .createNamedQuery(PayPalTransaction.GET_STATUS_AS_RECEPIENT, PayPalTransaction.class);

            queryResult.setMaxResults(range[1] - range[0] + 1);
            queryResult.setFirstResult(range[0]);

            queryResult.setParameter(paramName, payload);
            queryResult.setParameter("username", currentUser);

            StringBuilder builder = new StringBuilder();

            builder.append("[")
                    .append(payload.name())
                    .append("]");

            builder.append(" size: ")
                    .append(queryResult.getResultList().size());

            Logger.getLogger(this.getClass().getName()).log(Level.INFO,
                    builder.toString()
            );

            return queryResult.getResultList();

        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE,
                    "TransactionByStatusUser",
                    e);
            return new ArrayList<>();
        }
    }

    public float getAmount(String username) {
        return find(username).getAmount();
    }

    public void setAmount(String username, float amount) {
        PayPal pal = find(username);
        pal.setAmount(amount);
        edit(pal);
    }

    public void updateTransaction(PayPal current, PayPal rPal, float amountSend, float AmountRem) {
        current = em.merge(current);
        rPal = em.merge(rPal);
        current.setAmount(AmountRem);
        rPal.setAmount(amountSend);
        em.flush();
    }

    public void updateTransaction(PayPal current, PayPal rPal,
            float amountSend, float AmountRem,
            float transactionAmount, String transactionReference,
            String selected) {
        current = em.merge(current);
        rPal = em.merge(rPal);
        current.setAmount(AmountRem);
        rPal.setAmount(amountSend);
        current
                .addTransferTransaction(transactionAmount,
                        transactionReference, rPal.getRate(), selected);

        em.flush();
    }
}
