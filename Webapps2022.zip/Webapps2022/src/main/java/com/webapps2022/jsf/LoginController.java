/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalGroupFacade;
import com.webapps2022.utility.RoleType;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.enterprise.inject.Model;

/**
 *
 * @author josep
 */
@Model
public class LoginController {

    private String username;
    private String password;

    @EJB
    AuthenticationService service;

    @EJB
    PayPalGroupFacade groupService;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String login() {
        try {
            service.login(username, password);

            System.out.println(groupService
                    .getUserRole(username));

            if (groupService.getUserRole(username)
                    .equals(RoleType.USERS.getName())) {

                return "login_user";
            }

            return "login_admin";
        } catch (Exception ex) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE,
                    ex.getMessage());
            return null;
        }
    }

}
