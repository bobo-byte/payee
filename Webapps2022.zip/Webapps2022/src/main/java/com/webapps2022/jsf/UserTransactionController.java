/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalFacade;
import com.webapps2022.entity.PayPal;
import com.webapps2022.jsf.util.JsfUtil;
import com.webapps2022.restservice.ConverstionRestClient;
import com.webapps2022.utility.Rate;
import com.webapps2022.utility.TransactionType;
import java.io.Serializable;
import java.util.HashMap;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author Joseph Steven Semgalawe
 */
@Named("userTransactionController")
@ViewScoped
public class UserTransactionController implements Serializable {

    @EJB
    AuthenticationService authService;

    @EJB
    PayPalFacade dbService;

    private PayPal current;
    private float balance;
    private String selected;
    private float amountToSend;
    private String[] pals;
    private String transactionReference;
    private String currencySymbol;
    private String selectedSymbol;

    private HashMap<String, String> palsToSymbol;

    @PostConstruct
    private void init() {

        System.out.println("INITIALIZING");

        current = authService.getCurrentUser();
        palsToSymbol = new HashMap<>();

        System.out.println(current);

        if (current != null) {
            int userCount = dbService.getUserPalsCount(current.getUsername());

            if (userCount > 0) {
                pals = dbService.getUserPalsQuery(current.getUsername())
                        .map(pal -> {
                            palsToSymbol.putIfAbsent(pal.getUsername(),
                                    pal.getRate().getSymbol());
                            return pal.getUsername();
                        })
                        .toArray(String[]::new);

                selectedSymbol = getPalsSymbol(pals[0]);
            } else {
                pals = new String[0];
                selectedSymbol = "";
            }

            balance = current.getAmount();
            currencySymbol = current.getRate().getSymbol();
        } else {
            // testing
            int test = 1;
            if (test == 0) {
                balance = 1000;
                pals = new String[5];
                for (int i = 0; i < pals.length; i++) {
                    int userNumber = i + 1;
                    String generatedUsername = "user" + userNumber;
                    String randomSymbol = getRandomSymbol();
                    pals[i] = generatedUsername;
                    palsToSymbol.putIfAbsent(generatedUsername, randomSymbol);
                } // comment out to test if there are no pals to select
                currencySymbol = Rate.GBP.getSymbol();
                selectedSymbol = getPalsSymbol(pals[0]);
            } else {
                current = dbService.find("bobo");

                int userCount = dbService.getUserPalsCount(current.getUsername());

                if (userCount > 0) {
                    pals = dbService.getUserPalsQuery(current.getUsername())
                            .map(pal -> {
                                palsToSymbol.putIfAbsent(pal.getUsername(),
                                        pal.getRate().getSymbol());
                                return pal.getUsername();
                            })
                            .toArray(String[]::new);

                    selectedSymbol = getPalsSymbol(pals[0]);
                } else {
                    pals = new String[0];
                    selectedSymbol = "";
                }

                balance = current.getAmount();
                currencySymbol = current.getRate().getSymbol();
            }

        }

        amountToSend = 0;
        selected = "";
        transactionReference = "";
    }

    private void resetTransfer() {
        System.out.println("RESETING");
        float tmpBalance = this.balance - this.amountToSend;
        this.balance = tmpBalance;
        this.selected = "";
        this.amountToSend = 0;
        this.transactionReference = "";
    }

    private void resetRequest() {
        System.out.println("RESETING");
        this.selected = "";
        this.amountToSend = 0;
        this.transactionReference = "";
    }

    private void resetTransaction(TransactionType type) {

        if (TransactionType.REQUEST == type) {
            resetRequest();
        }

        if (TransactionType.TRANSFER == type) {
            resetTransfer();
        }

    }

    private String getRandomSymbol() {
        Rate[] values = Rate.values();
        int randomIndex = (int) ((Math.random() * values.length));

        return "(" + values[randomIndex].name() + ")" + values[randomIndex].getSymbol();
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public String getSelected() {
        return selected;
    }

    public void setSelected(String selected) {
        this.selected = selected;
    }

    public float getAmountToSend() {
        return amountToSend;
    }

    public void setAmountToSend(float amountToSend) {
        this.amountToSend = amountToSend;
    }

    public String[] getPals() {
        return pals;
    }

    public boolean isPal(String pal) {
        for (int i = 0, length = pals.length; i < length; i++) {
            if (pals[i].equals(pal)) {
                return true;
            }
        }

        return false;
    }

    public void setPals(String[] pals) {
        this.pals = pals;
    }

    public String getTransactionReference() {
        return transactionReference;
    }

    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }

    public String getCurrencySymbol() {
        return currencySymbol;
    }

    public void setCurrencySymbol(String currencySymbol) {
        this.currencySymbol = currencySymbol;
    }

    public String getPalsSymbol(String selected) {
        return palsToSymbol.get(selected);
    }

    public String getSelectedSymbol() {
        return selectedSymbol;
    }

    public void setSelectedSymbol(String selectedSymbol) {
        this.selectedSymbol = selectedSymbol;
    }

    public void selectMenuListener(AjaxBehaviorEvent event) {
        System.out.println("menu_change: " + this.selected);
        selectedSymbol = getPalsSymbol(this.selected);
    }

    public void onKeyPressPalUserNameListener(AjaxBehaviorEvent event) {
        if (palsToSymbol.containsKey(this.selected)) {
            selectedSymbol = getPalsSymbol(this.selected);
        } else {
            selectedSymbol = "";
        }
    }

    public String transfer() {

        boolean reset = false;
        boolean same;

        try {

            System.out.println("Making transfer...");

            System.out.println("Transaction info: " + this);

            System.out.println("Transactions size: " + current.getTransactions().size());

            System.out.println(selected);

            PayPal pal = dbService.find(selected);

            same = pal.getUsername().equals(current.getUsername());

            if (!same) {

                if (!isPal(selected)) {
                    current.addPal(pal);
                }

                float amountForCurrent = balance - amountToSend;
                float amountForPal = pal.getAmount() + amountToSend;

                if (!(pal.getRate() == current.getRate())) {
                    // different currencies.
                    String currency1 = current.getRate().name();
                    String currency2 = pal.getRate().name();

                    amountToSend = ConverstionRestClient
                            .getCurrencyConverstion(currency1, currency2,
                                    amountToSend);

                    amountForPal = pal.getAmount()
                            + amountToSend;
                }

                dbService.updateTransaction(current, pal,
                        amountForPal, amountForCurrent,
                        amountToSend, transactionReference, selected);

                JsfUtil.addSuccessMessage("Transfer complete ✔ "
                        + "\n "
                        + "Sent "
                        + selectedSymbol
                        + amountToSend
                        + " to " + selected);
                reset = true;

            } else {

                JsfUtil.addErrorMessage("🛑 " + "Username cannot "
                        + "be the same as current account!");
            }

        } catch (NullPointerException e) {
            JsfUtil.addErrorMessage("🛑 " + selected + " does not exist. "
                    + "Please enter a valid username");
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, "Failed to transfer money");
        }

        if (reset) {
            resetTransaction(TransactionType.TRANSFER);
        }
        return null; //transfer_success alternative
    }

    public String request() {
        boolean reset = false;
        boolean same;

        try {
            System.out.println("Making transfer...");

            System.out.println(this.toString());

            System.out.println(current.getTransactions().size());

            PayPal pal = dbService.find(selected);

            same = pal.getUsername().equals(current.getUsername());

            if (!same) {

                if (!isPal(selected)) {
                    current.addPal(pal);
                }

                if (!(pal.getRate() == current.getRate())) {
                    // different currencies.

                    String currency1 = current.getRate().name();
                    String currency2 = pal.getRate().name();

                    amountToSend = ConverstionRestClient
                            .getCurrencyConverstion(currency1, currency2,
                                    amountToSend);

                }

                current
                        .addRequestTransaction(amountToSend,
                                transactionReference, pal.getRate(), selected);

                JsfUtil.addSuccessMessage("Request complete ✔ "
                        + "\n "
                        + "Sent request for "
                        + selectedSymbol
                        + amountToSend
                        + " to " + selected);
                reset = true;

                dbService.edit(current);
            } else {
                JsfUtil.addErrorMessage("🛑 " + "Username cannot "
                        + "be the same as current account!");
            }

        } catch (NullPointerException e) {
            JsfUtil.addErrorMessage("🛑 " + selected + " does not exist. "
                    + "Please enter a valid username");
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, "Failed to transfer money");
        }

        if (reset) {
            resetTransaction(TransactionType.REQUEST);
        }
        return null;  // "request_success";
    }

    @Override
    public String toString() {
        return "UserTransactionController{" + "balance=" + balance
                + ", selected=" + selected
                + ", amountToSend=" + amountToSend
                + ", transactionReference=" + transactionReference
                + ", currencySymbol=" + currencySymbol + '}';
    }

}
