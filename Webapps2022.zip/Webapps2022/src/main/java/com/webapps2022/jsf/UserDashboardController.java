/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalFacade;
import com.webapps2022.entity.PayPal;
import com.webapps2022.utility.Rate;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.inject.Model;
import javax.faces.context.FacesContext;

/**
 *
 * @author Joseph Steven Semgalawe
 */
@Model
public class UserDashboardController implements Serializable {

    private String username;
    private float balance;
    private String symbol;
    private Rate rate;
    private PayPal current;

    @EJB
    PayPalFacade databaseService;

    @EJB
    AuthenticationService service;

    @PostConstruct
    private void init() {
        try {
            username = FacesContext
                    .getCurrentInstance().getExternalContext()
                    .getUserPrincipal().getName();

            current = databaseService.find(username);
//            balance = current.getMeta().getAmount();
//            rate = current.getMeta().getRate();
            balance = current.getAmount();
            rate = current.getRate();
            symbol = rate.getSymbol();

        } catch (Exception e) {
            // doesn't exist
            // for now :>

            username = "test";
            balance = 1000;
            rate = Rate.GBP;
            symbol = rate.getSymbol();

            System.out.println(e.getMessage());
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public Rate getRate() {
        return rate;
    }

    public void setRate(Rate rate) {
        this.rate = rate;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String logout() {
        System.out.println("Calling logout");

        try {
            service.logout();

            System.out.println("Logging out");

        } catch (Exception e) {
            System.out.println(e.getMessage());

            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE,
                    "Logout failed!");

            System.out.println("oops error");

            return null;
        }

        return "logout_success";
    }
}
