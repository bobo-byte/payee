/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.entity.PayPal;
import com.webapps2022.utility.RoleType;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.inject.Model;

/**
 *
 * @author josep
 */
@Model
public class RegistrationController implements Serializable {

    @EJB
    AuthenticationService service;

    PayPal newPayPal;

    @PostConstruct
    private void init() {
        if (newPayPal == null) {
            newPayPal = new PayPal();
        }
        System.out.println("INITALIZING: Registration");
    }

    public String create() {
        try {
            String password = newPayPal.getPassword();
            service.register(newPayPal, RoleType.USERS);

            service.login(newPayPal.getUsername(), password);

        } catch (Exception ex) {
            return null;
        }

        return "registration_success";
    }

    public PayPal getNewPayPal() {
        return newPayPal;
    }

    public void setNewPayPal(PayPal newPayPal) {
        this.newPayPal = newPayPal;
    }
}
