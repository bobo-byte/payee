package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalFacade;
import com.webapps2022.ejb.PayPalGroupFacade;
import com.webapps2022.entity.PayPal;
import com.webapps2022.jsf.annotations.Client;
import com.webapps2022.jsf.util.JsfUtil;
import com.webapps2022.jsf.util.PaginationHelper;
import com.webapps2022.utility.RoleType;
import java.io.Serializable;
import java.util.ResourceBundle;
import javax.ejb.EJB;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

@Client
public class PayPalController implements Serializable {

    private PayPal current;
    private DataModel items = null;
    @EJB
    private PayPalFacade ejbFacade;

    @EJB
    private AuthenticationService authService;

    @EJB
    private PayPalGroupFacade groupService;

    private PaginationHelper pagination;

    private PaginationHelper transactionPagination;
    private DataModel transactions = null;

    private boolean isAdmin;

    private int selectedItemIndex;

    public PayPalController() {
    }

    public PayPal getSelected() {
        if (current == null) {
            current = new PayPal();
            selectedItemIndex = -1;
        }
        return current;
    }

    public String getRole() {
        if (current == null) {
            return "";
        }
        return groupService.getUserRole(current.getUsername());
    }

    public boolean isIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    private PayPalFacade getFacade() {
        return ejbFacade;
    }

    public PaginationHelper getPagination() {
        if (pagination == null) {
            pagination = new PaginationHelper(2) {

                @Override
                public int getItemsCount() {
                    System.out.println("getFacade().count(): " + getFacade().count());
                    return getFacade().count();
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getFacade().findRange(new int[]{getPageFirstItem(), getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }
        return pagination;
    }

    public PaginationHelper getTransactionPagaintion() {
        if (transactionPagination == null) {
            transactionPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getFacade().getTransactionsCount(current.getUsername());
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getFacade().getTransactions(current.getUsername(), new int[]{getPageFirstItem(), getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }

        return transactionPagination;
    }

    public String prepareList() {
        recreateModel();
        return "list";
    }

    public String prepareTransaction() {
        recreateTransactionModel();
        return "transaction";
    }

    public String prepareView() {
        current = (PayPal) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "view";
    }

    public String prepareCreate() {
        current = new PayPal();
        selectedItemIndex = -1;
        isAdmin = false;
        return "create";
    }

    public String create() {
        try {
            if (isAdmin) {
                authService.register(current, RoleType.ADMINS);
            } else {
                authService.register(current, RoleType.USERS);
            }

            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("PayPalCreated"));
            return prepareCreate();
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public String prepareEdit() {
        current = (PayPal) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "edit";
    }

    public String update() {
        try {
            getFacade().edit(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("PayPalUpdated"));
            return "edit";
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public String destroy() {
        current = (PayPal) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        performDestroy();
        recreatePagination();
        recreateModel();
        return "list";
    }

    public String destroyAndView() {
        performDestroy();
        recreateModel();
        updateCurrentItem();
        if (selectedItemIndex >= 0) {
            return "view";
        } else {
            // all items were removed - go back to list
            recreateModel();
            return "list";
        }
    }

    private void performDestroy() {
        try {
            getFacade().remove(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("PayPalDeleted"));
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
        }
    }

    private void updateCurrentItem() {
        int count = getFacade().count();
        if (selectedItemIndex >= count) {
            // selected index cannot be bigger than number of items:
            selectedItemIndex = count - 1;
            // go to previous page if last page disappeared:
            if (pagination.getPageFirstItem() >= count) {
                pagination.previousPage();
            }
        }
        if (selectedItemIndex >= 0) {
            current = getFacade().findRange(new int[]{selectedItemIndex, selectedItemIndex + 1}).get(0);
        }
    }

    public DataModel getItems() {
        if (items == null) {
            items = getPagination().createPageDataModel();
        }
        return items;
    }

    public DataModel getTransactions() {
        if (transactions == null) {
            transactions = getTransactionPagaintion().createPageDataModel();
        }

        return transactions;
    }

    private void recreateModel() {
        items = null;
    }

    private void recreateTransactionModel() {
        transactions = null;
    }

    private void recreateTransactionPagination() {
        transactionPagination = null;
    }

    private void recreatePagination() {
        pagination = null;
    }

    public String next() {
        getPagination().nextPage();
        recreateModel();
        return "list";
    }

    public String previous() {
        getPagination().previousPage();
        recreateModel();
        return "list";
    }

    public String nextTransaction() {
        getTransactionPagaintion().nextPage();
        recreateTransactionModel();
        return "transaction";
    }

    public String previousTransaction() {
        getTransactionPagaintion().previousPage();
        recreateTransactionModel();
        return "transaction";
    }

    public SelectItem[] getItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
    }

    public SelectItem[] getItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
    }

    public PayPal getPayPal(java.lang.String id) {
        return ejbFacade.find(id);
    }

    @FacesConverter(forClass = PayPal.class)
    public static class PayPalControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            PayPalController controller = (PayPalController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "payPalController");
            return controller.getPayPal(getKey(value));
        }

        java.lang.String getKey(String value) {
            java.lang.String key;
            key = value;
            return key;
        }

        String getStringKey(java.lang.String value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof PayPal) {
                PayPal o = (PayPal) object;
                return getStringKey(o.getUsername());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + PayPal.class.getName());
            }
        }

    }

}
