/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalFacade;
import com.webapps2022.ejb.PayPalTransactionFacade;
import com.webapps2022.entity.PayPal;
import com.webapps2022.entity.PayPalTransaction;
import com.webapps2022.jsf.util.JsfUtil;
import com.webapps2022.jsf.util.PaginationHelper;
import com.webapps2022.utility.TransactionStatus;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author josep
 */
@Named("userTransactionsController")
@ViewScoped
public class UserTransactionsController implements Serializable {

    private PaginationHelper completedPagination;
    private PaginationHelper pendingPagination;
    private PaginationHelper rejectedPagination;

    private DataModel completedTransactions;
    private DataModel pendingTransactions;
    private DataModel rejectedTransactions;

    private DataModel receivedCompletedTransactions;
    private DataModel receivedRejectedTransactions;
    private DataModel receivedPendingTransactions;

    private PaginationHelper receivedCompletedPagination;
    private PaginationHelper receivedRejectedPagination;
    private PaginationHelper receivedPendingPagination;

    private int selectedCompleteTransactionIndex;
    private int selectedPendingTransactionIndex;
    private int selectedRejectedTransactionIndex;

    private PayPalTransaction transaction;

    @EJB
    AuthenticationService service;

    String username;

    PayPal current;

    @EJB
    private PayPalFacade ejb;

    @EJB
    private PayPalTransactionFacade transactionService;

    @PostConstruct
    private void init() {
        System.out.println("INITIALIZING...");

        try {
            current = service.getCurrentUser();
            username = current.getUsername();
        } catch (NullPointerException e1) {
            Logger.getLogger(this.getClass().getName()).log(Level.INFO, "INITALIZING AS TEST");
            current = ejb.find("bobo5"); // test
            username = current.getUsername();
        } catch (Exception e2) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e2);
        }

    }

    public PaginationHelper getCompletedPagination() {
        if (completedPagination == null) {
            completedPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getEjb().getTransactionsByStatusCount(username, TransactionStatus.ACCEPTED);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getEjb()
                            .getTransactionsByStatusQuery(username, TransactionStatus.ACCEPTED,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }
        return completedPagination;
    }

    public PaginationHelper getPendingPagination() {
        if (pendingPagination == null) {
            pendingPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getEjb().getTransactionsByStatusCount(username, TransactionStatus.PENDING);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getEjb()
                            .getTransactionsByStatusQuery(username, TransactionStatus.PENDING,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem()
                                        + getPageSize() - 1}));
                }
            };
        }
        return pendingPagination;
    }

    public PaginationHelper getRejectedPagination() {
        if (rejectedPagination == null) {
            rejectedPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getEjb().getTransactionsByStatusCount(username, TransactionStatus.REJECTED);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getEjb()
                            .getTransactionsByStatusQuery(username, TransactionStatus.REJECTED,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }
        return rejectedPagination;
    }

    public PaginationHelper getReceivedCompletedPagination() {
        if (receivedCompletedPagination == null) {
            receivedCompletedPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getEjb().getUserReceivedTransactionsByStatusCount(username,
                            TransactionStatus.ACCEPTED);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(
                            getEjb().getUserReceivedTransactionByStatus(username,
                                    TransactionStatus.ACCEPTED,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }

        return receivedCompletedPagination;
    }

    public PaginationHelper getReceivedRejectedPagination() {
        if (receivedRejectedPagination == null) {
            receivedRejectedPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getEjb().getUserReceivedTransactionsByStatusCount(username,
                            TransactionStatus.REJECTED);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(
                            getEjb().getUserReceivedTransactionByStatus(username,
                                    TransactionStatus.REJECTED,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }

        return receivedRejectedPagination;
    }

    public PaginationHelper getReceivedPendingPagination() {
        if (receivedPendingPagination == null) {
            receivedPendingPagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return getEjb().getUserReceivedTransactionsByStatusCount(username,
                            TransactionStatus.PENDING);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(
                            getEjb().getUserReceivedTransactionByStatus(username,
                                    TransactionStatus.PENDING,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem() + getPageSize() - 1}));
                }
            };
        }

        return receivedPendingPagination;
    }

    public DataModel getRejectedItems() {
        if (rejectedTransactions == null) {
            rejectedTransactions = getRejectedPagination().createPageDataModel();
        }
        return rejectedTransactions;
    }

    public DataModel getCompletedItems() {
        if (completedTransactions == null) {
            completedTransactions = getCompletedPagination().createPageDataModel();
        }
        return completedTransactions;
    }

    public DataModel getPendingItems() {
        if (pendingTransactions == null) {
            pendingTransactions = getPendingPagination().createPageDataModel();
        }
        return pendingTransactions;
    }

    public void nextPending() {
        pendingPagination.nextPage();
        pendingTransactions = null;
    }

    public void previousPending() {
        pendingPagination.previousPage();
        pendingTransactions = null;
    }

    public void nextComplete() {
        completedPagination.nextPage();
        completedTransactions = null;
    }

    public void previousComplete() {
        completedPagination.previousPage();
        completedTransactions = null;
    }

    public void nextRejected() {
        rejectedPagination.nextPage();
        rejectedTransactions = null;
    }

    public void previousRejected() {
        rejectedPagination.previousPage();
        rejectedTransactions = null;
    }

    public void receivedNextComplete() {
        receivedCompletedPagination.nextPage();
        receivedCompletedTransactions = null;
    }

    public void receivedPreviousComplete() {
        receivedCompletedPagination.previousPage();
        receivedCompletedTransactions = null;
    }

    public void receivedNextPending() {
        receivedPendingPagination.nextPage();
        receivedPendingTransactions = null;
    }

    public void receivedPreviousPending() {
        receivedPendingPagination.previousPage();
        receivedPendingTransactions = null;
    }

    public void receivedNextRejected() {
        receivedRejectedPagination.nextPage();
        receivedRejectedTransactions = null;
    }

    public void receivedPreviousRejected() {
        receivedRejectedPagination.previousPage();
        receivedRejectedTransactions = null;
    }

    public DataModel getReceivedCompletedItems() {
        if (receivedCompletedTransactions == null) {
            receivedCompletedTransactions
                    = getReceivedCompletedPagination()
                            .createPageDataModel();
        }

        return receivedCompletedTransactions;
    }

    public DataModel getReceivedRejectedItems() {
        if (receivedRejectedTransactions == null) {
            receivedRejectedTransactions
                    = getReceivedRejectedPagination()
                            .createPageDataModel();
        }

        return receivedRejectedTransactions;
    }

    public DataModel getReceivedPendingItems() {
        if (receivedPendingTransactions == null) {
            receivedPendingTransactions
                    = getReceivedPendingPagination()
                            .createPageDataModel();
        }

        return receivedPendingTransactions;
    }

    public PayPalFacade getEjb() {
        return ejb;
    }

    public void setTransaction(PayPalTransaction transaction) {
        this.transaction = transaction;
    }

    public String accept() {
        try {
            transaction = (PayPalTransaction) getReceivedPendingItems().getRowData();
            selectedPendingTransactionIndex
                    = receivedPendingPagination.getPageFirstItem()
                    + getPendingItems().getRowIndex();

            // cannot accept a request that is above what is available.
            if (transaction.getAmount() > current.getAmount()) {
                // Throw not enough funds available.

                JsfUtil.addErrorMessage("rPendingForm", "Not enough funds available to complete"
                        + " transaction");

                return null; //refresh with the error. State remains the same.
            } else {
                transaction.setStatus(TransactionStatus.ACCEPTED);

                // add money to requesting user account.
                String rUsername = transaction.getUser().getUsername();
                PayPal requestee = getEjb().find(rUsername);
                float requesteeBalance = requestee.getAmount();
                float toSendAmount = transaction.getAmount() + requesteeBalance;

                if (current.getRate() != transaction.getUser().getRate()) {
                    float exchangeRate = current.getRate().getRates()
                            .get(transaction.getUser().getRate().name());

                    toSendAmount = requesteeBalance
                            + (transaction.getAmount() * exchangeRate);
                }

                // remove money from current user
                float amountRem = current.getAmount() - transaction.getAmount();

                ejb
                        .updateTransaction(current,
                                requestee, toSendAmount, amountRem);

                transactionService.edit(transaction);

            }

        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.INFO,
                    "Transaction conflict: ", e);
            JsfUtil.addErrorMessage("rPendingForm", "Opps something went wrong. Please contact"
                    + " admin for help");
            return null;
        }

        // ejb.edit(current);
        return "accept_success";
    }

    public String reject() {
        try {
            transaction = (PayPalTransaction) getReceivedPendingItems().getRowData();
            selectedPendingTransactionIndex
                    = receivedPendingPagination.getPageFirstItem()
                    + getPendingItems().getRowIndex();

            transaction.setStatus(TransactionStatus.REJECTED);
            transactionService.edit(transaction);

        } catch (Exception e) {
            Logger.getLogger(this.getClass().getName()).log(Level.INFO,
                    "Transaction conflict: ", e);
            return null;
        }

        return "reject_success";
    }
}
