/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalFacade;
import com.webapps2022.entity.PayPal;
import com.webapps2022.jsf.util.JsfUtil;
import com.webapps2022.restservice.ConverstionRestClient;
import com.webapps2022.utility.Rate;
import java.io.Serializable;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author josep
 */
@Named("userEditController")
@ViewScoped
public class UserEditController implements Serializable {

    PayPal current;

    @EJB
    AuthenticationService authService;

    @EJB
    PayPalFacade dbService;

    private String username;
    private String email;
    private String password;
    private Rate originalCurrency;
    private String currency;
    private float originalAmount;
    private float exchangeAmount;

    private String[] values;

    @PostConstruct
    private void init() {
        System.out.println("INITALIZING...");

        try {
            if (current == null) {
                current = authService.getCurrentUser();
                email = current.getEmail();
                username = current.getUsername();
                originalCurrency = current.getRate();
                originalAmount = current.getAmount();
                exchangeAmount = originalAmount;
                currency = originalCurrency.toString(); //default.
            }
        } catch (NullPointerException e1) {
            Logger.getLogger(this.getClass()
                    .getName())
                    .log(Level.INFO,
                            "INITALIZING AS TEST");
            current = null;
            email = "josephsteven777@gmail.com";
            username = "bobo";
            currency = Rate.GBP.toString();
            originalCurrency = Rate.GBP;
            originalAmount = 1000;
            exchangeAmount = originalAmount;

        } catch (Exception e2) {
            Logger.getLogger(this.getClass()
                    .getName())
                    .log(Level.SEVERE, null, e2);
            current = null;
        }

        values = Arrays.stream(Rate.values())
                .map(rates -> {
                    return rates.toString();
                }).toArray(String[]::new);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String[] getValues() {
        return values;
    }

    public void setValues(String[] values) {
        this.values = values;
    }

    public String getOriginalCurrency() {
        return originalCurrency.toString();
    }

    public void setOriginalCurrency(Rate originalCurrency) {
        this.originalCurrency = originalCurrency;
    }

    public float getOriginalAmount() {
        return originalAmount;
    }

    public float getExchangeAmount() {
        return ConverstionRestClient
                .getCurrencyConverstion(originalCurrency.name(),
                        currency, originalAmount);
    }

    public void setExchangeAmount(float exchangeAmount) {
        this.exchangeAmount = exchangeAmount;
    }

    public void update() {
        try {
            current.setEmail(email);
            current.setUsername(username);
            current.setRate(Rate.getRate(currency));
            current.setAmount(getExchangeAmount());
            dbService.edit(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/Bundle").getString("PayPalUpdated"));
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/Bundle").getString("PersistenceErrorOccured"));
        }
    }

}
