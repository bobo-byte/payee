/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.jsf;

import com.webapps2022.ejb.AuthenticationService;
import com.webapps2022.ejb.PayPalFacade;
import com.webapps2022.jsf.util.PaginationHelper;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 *
 * @author josep
 */
@Named("userPalsController")
@ViewScoped
public class UserPalsController implements Serializable {

    @EJB
    AuthenticationService service;

    @EJB
    PayPalFacade dbService;

    PaginationHelper pagination;

    private DataModel items;

    String current;

    @PostConstruct
    private void init() {
        System.out.println("INITIALIZING...");

        try {
            if (current == null) {
                current = service.getCurrentUser().getUsername();
            }
        } catch (NullPointerException e1) {
            Logger.getLogger(this.getClass().getName()).log(Level.INFO, "INITALIZING AS TEST");
            current = null;
        } catch (Exception e2) {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, e2);
            current = null;
        }
    }

    public PaginationHelper getPagination() {
        if (pagination == null) {
            pagination = new PaginationHelper(2) {
                @Override
                public int getItemsCount() {
                    return dbService.getUserPalsCount(current);
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(dbService
                            .getUserPalsQuery(current,
                                    new int[]{getPageFirstItem(),
                                        getPageFirstItem()
                                        + getPageSize() - 1}));
                }
            };
        }

        return pagination;
    }

    public DataModel getItems() {
        if (items == null) {
            items = getPagination().createPageDataModel();
        }
        return items;
    }

    public void next() {
        pagination.nextPage();
        items = null;
    }

    public void previous() {
        pagination.previousPage();
        items = null;
    }

}
