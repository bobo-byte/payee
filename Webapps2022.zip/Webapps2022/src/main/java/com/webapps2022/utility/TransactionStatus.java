/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.webapps2022.utility;

/**
 *
 * @author Joseph Steven Semgalawe
 */
public enum TransactionStatus {
    ACCEPTED,
    PENDING,
    REJECTED,
}
