/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.webapps2022.utility;

import java.util.HashMap;

/**
 * Class for getting currency rates and currency type
 *
 * @author Joseph Steven Semgalawe
 */
public enum Rate {
    GBP("BRITISH_POUNDS"),
    USD("AMERICAN_DOLLARS"),
    EUR("EUROPEAN_EUROS");

    private String name;
    private String symbol;
    private HashMap<String, Float> exchangeRates;

    private Rate(String name) {
        this.name = name;
        this.symbol = RateSymbol.valueOf(name).getSymbol();
        setExchangeRates();
    }

    public static Rate getRate(String name) {
        switch (name) {
            case "GBP":
                return Rate.GBP;
            case "USD":
                return Rate.USD;
            case "EUR":
                return Rate.EUR;
            default:
                break;
        }

        return null;
    }

    /**
     * Getter for the name of currency
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for currency name
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for currency symbol
     *
     * @return
     */
    public String getSymbol() {
        return symbol;
    }

    /**
     * Setter for currency symbol
     *
     * @param symbol
     */
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    /**
     * Method for setting the exchange rates of different currencies.
     */
    private void setExchangeRates() {
        this.exchangeRates = new HashMap<>();
        System.out.println(name());
        switch (this.name) {
            case "EUROPEAN_EUROS":
                exchangeRates.put("GBP", 0.83067673f);
                exchangeRates.put("USD", 1.0855462f);
                break;
            case "AMERICAN_DOLLARS":
                exchangeRates.put("EUR", 0.92119527f);
                exchangeRates.put("GBP", 0.76521548f);
                break;
            default: // BRITISH_POUNDS
                exchangeRates.put("USD", 1.3068215f);
                exchangeRates.put("EUR", 1.2038377f);
                break;
        }
    }

    /**
     * Getter method for currency exchange rate
     *
     * @return exchange rates
     */
    public HashMap<String, Float> getRates() {
        return exchangeRates;
    }

    public static HashMap<String, Float> getRatesBySymbol(String symbol) {
        switch (symbol) {
            case "$":
                return Rate.USD.exchangeRates;

            case "£":
                return Rate.GBP.exchangeRates;

            case "€":
                return Rate.EUR.exchangeRates;
            default: // EMPTY
                return new HashMap();

        }
    }

    public static HashMap<String, Float> getRatesByName(String name) {
        switch (name) {
            case "USD":
                return Rate.USD.exchangeRates;

            case "GBP":
                return Rate.GBP.exchangeRates;

            case "EUR":
                return Rate.EUR.exchangeRates;
            default: // EMPTY
                return new HashMap();

        }
    }

    /**
     * Class for mapping currency to currency symbol
     */
    private enum RateSymbol {
        BRITISH_POUNDS("£"),
        AMERICAN_DOLLARS("$"),
        EUROPEAN_EUROS("€");

        private String symbol;

        private RateSymbol(String symbol) {
            this.symbol = symbol;
        }

        /**
         * Getter method for currency symbol
         *
         * @return currency symbol
         */
        public String getSymbol() {
            return symbol;
        }

        /**
         * Setter method for currency symbol
         *
         * @param symbol currency symbol
         */
        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }
    }
}
