/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package com.webapps2022.utility;

/**
 *
 * @author Joseph Steven Semgalawe
 */
public enum PayPalQuery {
    GET_TRANSACTIONS("SELECT t FROM PayPal p"
            + " LEFT JOIN p.transactions t WHERE p.username = :username"),
    GET_TRANSACTION("SELECT DISTINCT t FROM PayPal p" 
            + " LEFT JOIN p.transactions t WHERE t.id = :transactionID"),
    GET_USER("SELECT DISTINCT p FROM PayPal p WHERE p.username = :username");
    
    
    private String query;
    
    private PayPalQuery(String query) {
        this.query = query;
    }

    
    /**
     * Getter for query value
     * @return 
     */
    public String getQuery() {
        return query;
    }

    /**
     * Setter to override query
     * @param query 
     */
    public void setQuery(String query) {
        this.query = query;
    }
    
    
    
}
