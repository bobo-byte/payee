/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.restservice;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author josep
 */
public class ConverstionRestClient {

    public static Float getCurrencyConverstion(String c1, String c2, float amount) {
        String webappURL = "http://localhost:10000/Webapps2022/";
        String restPath = "api/conversion/"
                + c1 + "/" + c2 + "/" + amount;
        String path = webappURL + restPath;

        Client client = ClientBuilder.newClient();
        WebTarget resource = client.target(path);

        Invocation.Builder builder = resource.request(MediaType.APPLICATION_JSON);
        Float response = builder.get(Float.class);
        client.close();

        return response;
    }

}
