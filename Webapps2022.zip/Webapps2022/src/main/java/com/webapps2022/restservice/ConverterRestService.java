/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.webapps2022.restservice;

import com.webapps2022.utility.Rate;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author josep
 */
@Path("/conversion")
public class ConverterRestService {

    @GET
    @Path("/{currency1}/{currency2}/{amount_of_currency1}")
    @Produces({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    public Float getResult(@PathParam("currency1") String c1, @PathParam("currency2") String c2, @PathParam("amount_of_currency1") String amount) {

        float amountToConvert;

        try {
            amountToConvert = Float.parseFloat(amount);
        } catch (NumberFormatException e) {
            Logger.getLogger(this.getClass().getName()).log(Level.WARNING,
                    e.getMessage());
            return null;
        }

        float result = amountToConvert;

        HashMap<String, Float> rates = Rate.getRatesByName(c1);

        if (!rates.containsKey(c2)) {
            if (c1.equals(c2)) {
                return result;
            }

            return null;
        }

        float exchangeRate = rates.get(c2);

        result = amountToConvert * exchangeRate;

        return result;

    }

}
